#include "ofApp.h"

void ofApp::setup()
{
	ofBackground(34, 34, 34);
	ofSetVerticalSync(false);
	ofEnableAlphaBlending();

	image.loadImage("images/texture.jpg");

    shader.load("shaders/planet.vert", "shaders/planet.frag");
}

void ofApp::exit()
{
    shader.unload();
}

void ofApp::update()
{

}

void ofApp::draw()
{
	ofSetColor(225);
	ofDrawBitmapString("coucou", 10, 20);

	shader.begin();
    shader.setUniformTexture("uTexture0", image, 1);
	shader.setUniform1f("uTime", ofGetElapsedTimef());
	shader.setUniform2f("uMouse", mouseX - ofGetWidth()/2, ofGetHeight()/2-mouseY);
	shader.setUniform2f("uResolution", ofGetWidth(), ofGetHeight());
    shader.setUniform2f("uTextureResolution", image.getWidth(), image.getHeight());

	ofDrawPlane(ofGetWidth() * .5, ofGetHeight() * .5, ofGetWidth(), ofGetHeight());
	shader.end();
}

void ofApp::keyPressed (int key)
{
}

void ofApp::keyReleased(int key)
{
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){

}

